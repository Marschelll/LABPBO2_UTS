package soal1;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

// Kelas soal1.Karyawan untuk menyimpan data karyawan
class Karyawan {
    private String id;
    private String nama;
    private String posisi;
    private double gaji;
    private String divisi;

    // Constructor
    public Karyawan(String id, String nama, String posisi, double gaji, String divisi) {
        this.id = id;
        this.nama = nama;
        this.posisi = posisi;
        this.gaji = gaji;
        this.divisi = divisi;
    }

    // Getter dan Setter
    public String getId() { return id; }
    public String getNama() { return nama; }
    public String getPosisi() { return posisi; }
    public void setPosisi(String posisi) { this.posisi = posisi; }
    public double getGaji() { return gaji; }
    public void setGaji(double gaji) { this.gaji = gaji; }
    public String getDivisi() { return divisi; }

    // Method untuk format data ke file
    public String toFileString() {
        return id + "," + nama + "," + posisi + "," + gaji + "," + divisi;
    }

    // Method untuk menampilkan informasi karyawan
    @Override
    public String toString() {
        return "ID: " + id + ", Nama: " + nama + ", Posisi: " + posisi +
                ", Gaji: " + gaji + ", Divisi: " + divisi;
    }
}

// Kelas soal1.Perusahaan untuk mengelola daftar karyawan
class Perusahaan {
    private List<Karyawan> daftarKaryawan;
    private static final String FILE_NAME = "karyawan.txt";

    // Constructor
    public Perusahaan() {
        daftarKaryawan = new ArrayList<>();
        muatDariFile();
    }

    // Method untuk menambahkan karyawan
    public boolean tambahKaryawan(Karyawan karyawan) {
        // Validasi ID duplikat
        for (Karyawan k : daftarKaryawan) {
            if (k.getId().equals(karyawan.getId())) {
                JOptionPane.showMessageDialog(null, "Error: ID karyawan sudah ada!");
                return false;
            }
        }
        // Validasi gaji
        if (karyawan.getGaji() < 0) {
            JOptionPane.showMessageDialog(null, "Error: Gaji tidak boleh negatif!");
            return false;
        }
        daftarKaryawan.add(karyawan);
        simpanKeFile();
        return true;
    }

    // Method untuk menghapus karyawan
    public boolean hapusKaryawan(String id) {
        Karyawan karyawan = cariKaryawan(id);
        if (karyawan != null) {
            daftarKaryawan.remove(karyawan);
            simpanKeFile();
            return true;
        }
        JOptionPane.showMessageDialog(null, "Error: soal1.Karyawan dengan ID " + id + " tidak ditemukan.");
        return false;
    }

    // Method untuk mengubah posisi
    public boolean ubahPosisi(String id, String posisiBaru) {
        Karyawan karyawan = cariKaryawan(id);
        if (karyawan != null) {
            karyawan.setPosisi(posisiBaru);
            simpanKeFile();
            return true;
        }
        JOptionPane.showMessageDialog(null, "Error: soal1.Karyawan dengan ID " + id + " tidak ditemukan.");
        return false;
    }

    // Method untuk mengubah gaji
    public boolean ubahGaji(String id, double gajiBaru) {
        Karyawan karyawan = cariKaryawan(id);
        if (karyawan != null) {
            if (gajiBaru < 0) {
                JOptionPane.showMessageDialog(null, "Error: Gaji tidak boleh negatif!");
                return false;
            }
            karyawan.setGaji(gajiBaru);
            simpanKeFile();
            return true;
        }
        JOptionPane.showMessageDialog(null, "Error: soal1.Karyawan dengan ID " + id + " tidak ditemukan.");
        return false;
    }

    // Method untuk mencari karyawan
    public Karyawan cariKaryawan(String id) {
        for (Karyawan k : daftarKaryawan) {
            if (k.getId().equals(id)) {
                return k;
            }
        }
        return null;
    }

    // Method untuk mendapatkan semua karyawan
    public List<Karyawan> getDaftarKaryawan() {
        return daftarKaryawan;
    }

    // Method untuk filter berdasarkan posisi
    public List<Karyawan> filterByPosisi(String posisi) {
        List<Karyawan> hasil = new ArrayList<>();
        for (Karyawan k : daftarKaryawan) {
            if (k.getPosisi().equalsIgnoreCase(posisi)) {
                hasil.add(k);
            }
        }
        return hasil;
    }

    // Method untuk menghitung total gaji
    public double hitungTotalGaji() {
        double total = 0;
        for (Karyawan k : daftarKaryawan) {
            total += k.getGaji();
        }
        return total;
    }

    // Method untuk menyimpan data ke file
    private void simpanKeFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_NAME))) {
            for (Karyawan k : daftarKaryawan) {
                writer.write(k.toFileString());
                writer.newLine();
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error saat menyimpan ke file: " + e.getMessage());
        }
    }

    // Method untuk memuat data dari file
    private void muatDariFile() {
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_NAME))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                if (data.length == 5) {
                    Karyawan karyawan = new Karyawan(data[0], data[1], data[2], Double.parseDouble(data[3]), data[4]);
                    daftarKaryawan.add(karyawan);
                }
            }
        } catch (FileNotFoundException e) {
            // File belum ada, tidak perlu tindakan
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error saat memuat dari file: " + e.getMessage());
        }
    }
}

// Kelas untuk GUI menggunakan Swing
class EmployeeManagementGUI extends JFrame {
    private Perusahaan perusahaan;
    private DefaultTableModel tableModel;
    private JTable table;
    private JTextField idField, namaField, posisiField, gajiField, divisiField, filterField;

    public EmployeeManagementGUI() {
        perusahaan = new Perusahaan();
        initUI();
    }

    // Inisialisasi komponen GUI
    private void initUI() {
        setTitle("Sistem Manajemen soal1.Karyawan");
        setSize(800, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Panel utama
        JPanel mainPanel = new JPanel(new BorderLayout());
        add(mainPanel);

        // Tabel untuk menampilkan karyawan
        String[] columns = {"ID", "Nama", "Posisi", "Gaji", "Divisi"};
        tableModel = new DefaultTableModel(columns, 0);
        table = new JTable(tableModel);
        updateTable(perusahaan.getDaftarKaryawan());
        JScrollPane scrollPane = new JScrollPane(table);
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        // Panel input
        JPanel inputPanel = new JPanel(new GridLayout(6, 2, 10, 10));
        inputPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        inputPanel.add(new JLabel("ID:"));
        idField = new JTextField();
        inputPanel.add(idField);

        inputPanel.add(new JLabel("Nama:"));
        namaField = new JTextField();
        inputPanel.add(namaField);

        inputPanel.add(new JLabel("Posisi:"));
        posisiField = new JTextField();
        inputPanel.add(posisiField);

        inputPanel.add(new JLabel("Gaji:"));
        gajiField = new JTextField();
        inputPanel.add(gajiField);

        inputPanel.add(new JLabel("Divisi:"));
        divisiField = new JTextField();
        inputPanel.add(divisiField);

        mainPanel.add(inputPanel, BorderLayout.NORTH);

        // Panel tombol
        JPanel buttonPanel = new JPanel(new FlowLayout());
        JButton tambahButton = new JButton("Tambah soal1.Karyawan");
        JButton ubahPosisiButton = new JButton("Ubah Posisi");
        JButton ubahGajiButton = new JButton("Ubah Gaji");
        JButton hapusButton = new JButton("Hapus soal1.Karyawan");
        JButton filterButton = new JButton("Filter Posisi");
        filterField = new JTextField(10);
        JButton totalGajiButton = new JButton("Tampilkan Total Gaji");

        buttonPanel.add(tambahButton);
        buttonPanel.add(ubahPosisiButton);
        buttonPanel.add(ubahGajiButton);
        buttonPanel.add(hapusButton);
        buttonPanel.add(new JLabel("Filter Posisi:"));
        buttonPanel.add(filterField);
        buttonPanel.add(filterButton);
        buttonPanel.add(totalGajiButton);

        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        // Action listeners untuk tombol
        tambahButton.addActionListener(e -> tambahKaryawan());
        ubahPosisiButton.addActionListener(e -> ubahPosisi());
        ubahGajiButton.addActionListener(e -> ubahGaji());
        hapusButton.addActionListener(e -> hapusKaryawan());
        filterButton.addActionListener(e -> filterPosisi());
        totalGajiButton.addActionListener(e -> tampilkanTotalGaji());
    }

    // Method untuk memperbarui tabel
    private void updateTable(List<Karyawan> karyawanList) {
        tableModel.setRowCount(0);
        for (Karyawan k : karyawanList) {
            tableModel.addRow(new Object[]{k.getId(), k.getNama(), k.getPosisi(), k.getGaji(), k.getDivisi()});
        }
    }

    // Method untuk menambah karyawan
    private void tambahKaryawan() {
        try {
            String id = idField.getText();
            String nama = namaField.getText();
            String posisi = posisiField.getText();
            double gaji = Double.parseDouble(gajiField.getText());
            String divisi = divisiField.getText();

            if (id.isEmpty() || nama.isEmpty() || posisi.isEmpty() || divisi.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Semua field harus diisi!");
                return;
            }

            Karyawan karyawan = new Karyawan(id, nama, posisi, gaji, divisi);
            if (perusahaan.tambahKaryawan(karyawan)) {
                updateTable(perusahaan.getDaftarKaryawan());
                clearFields();
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Gaji harus berupa angka!");
        }
    }

    // Method untuk mengubah posisi
    private void ubahPosisi() {
        String id = idField.getText();
        String posisiBaru = posisiField.getText();
        if (id.isEmpty() || posisiBaru.isEmpty()) {
            JOptionPane.showMessageDialog(this, "ID dan Posisi harus diisi!");
            return;
        }
        if (perusahaan.ubahPosisi(id, posisiBaru)) {
            updateTable(perusahaan.getDaftarKaryawan());
            clearFields();
        }
    }

    // Method untuk mengubah gaji
    private void ubahGaji() {
        try {
            String id = idField.getText();
            double gajiBaru = Double.parseDouble(gajiField.getText());
            if (id.isEmpty()) {
                JOptionPane.showMessageDialog(this, "ID harus diisi!");
                return;
            }
            if (perusahaan.ubahGaji(id, gajiBaru)) {
                updateTable(perusahaan.getDaftarKaryawan());
                clearFields();
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Gaji harus berupa angka!");
        }
    }

    // Method untuk menghapus karyawan
    private void hapusKaryawan() {
        String id = idField.getText();
        if (id.isEmpty()) {
            JOptionPane.showMessageDialog(this, "ID harus diisi!");
            return;
        }
        if (perusahaan.hapusKaryawan(id)) {
            updateTable(perusahaan.getDaftarKaryawan());
            clearFields();
        }
    }

    // Method untuk memfilter berdasarkan posisi
    private void filterPosisi() {
        String posisi = filterField.getText();
        if (posisi.isEmpty()) {
            updateTable(perusahaan.getDaftarKaryawan());
        } else {
            updateTable(perusahaan.filterByPosisi(posisi));
        }
    }

    // Method untuk menampilkan total gaji
    private void tampilkanTotalGaji() {
        double total = perusahaan.hitungTotalGaji();
        JOptionPane.showMessageDialog(this, "Total Gaji Semua soal1.Karyawan: " + total);
    }

    // Method untuk mengosongkan field input
    private void clearFields() {
        idField.setText("");
        namaField.setText("");
        posisiField.setText("");
        gajiField.setText("");
        divisiField.setText("");
    }
}

// Kelas utama untuk menjalankan aplikasi
public class SistemManajemenDataKaryawan {
    public static void main(String[] args) {
        // Menjalankan GUI di thread EDT
        SwingUtilities.invokeLater(() -> {
            EmployeeManagementGUI gui = new EmployeeManagementGUI();
            gui.setVisible(true);
        });
    }
}