package soal3;

import java.util.Random;
import java.util.Scanner;

// Kelas soal3.LotreBoard untuk mengelola papan permainan lotre gosok
class LotreBoard {
    private char[][] board; // Papan untuk tampilan (*: belum dibuka, O: aman, X: bom)
    private boolean[][] revealed; // Status apakah kotak sudah dibuka
    private int[][] data; // Data asli (0: aman, 1: bom)
    private int safeCount; // Jumlah kotak aman yang sudah dibuka
    private boolean bombHit; // Status apakah bom ditemukan
    private static final int ROWS = 4;
    private static final int COLS = 5;
    private static final int BOMB_COUNT = 2;
    private static final int TOTAL_SAFE = ROWS * COLS - BOMB_COUNT;

    // Constructor
    public LotreBoard() {
        board = new char[ROWS][COLS];
        revealed = new boolean[ROWS][COLS];
        data = new int[ROWS][COLS];
        safeCount = 0;
        bombHit = false;
        generateBoard();
    }

    // Method untuk menginisialisasi papan dengan 2 bom secara acak
    public void generateBoard() {
        // Inisialisasi papan dengan kotak belum dibuka dan aman
        for (int i = 0; i < ROWS; i++) {
            for (int j = 0; j < COLS; j++) {
                board[i][j] = '*';
                revealed[i][j] = false;
                data[i][j] = 0; // Aman
            }
        }

        // Menempatkan 2 bom secara acak
        Random random = new Random();
        int bombsPlaced = 0;
        while (bombsPlaced < BOMB_COUNT) {
            int row = random.nextInt(ROWS);
            int col = random.nextInt(COLS);
            if (data[row][col] == 0) {
                data[row][col] = 1; // Bom
                bombsPlaced++;
            }
        }
    }

    // Method untuk menampilkan papan saat ini
    public void displayBoard() {
        System.out.println("\nPapan Lotre Gosok:");
        System.out.println("   0 1 2 3 4"); // Header kolom
        System.out.println("  -----------");
        for (int i = 0; i < ROWS; i++) {
            System.out.print(i + " |");
            for (int j = 0; j < COLS; j++) {
                System.out.print(board[i][j] + " ");
            }
            System.out.println("|");
        }
        System.out.println("  -----------");
    }

    // Method untuk memproses tebakan pemain
    public boolean guess(int row, int col) {
        // Validasi input
        if (row < 0 || row >= ROWS || col < 0 || col >= COLS) {
            System.out.println("Error: Baris harus 0-3, kolom harus 0-4!");
            return true; // Lanjutkan permainan
        }
        if (revealed[row][col]) {
            System.out.println("Error: Kotak ini sudah dibuka!");
            return true; // Lanjutkan permainan
        }

        // Tandai kotak sebagai dibuka
        revealed[row][col] = true;

        // Cek apakah bom
        if (data[row][col] == 1) {
            board[row][col] = 'X';
            bombHit = true;
            return false; // Pemain kalah
        } else {
            board[row][col] = 'O';
            safeCount++;
            return true; // Kotak aman, lanjutkan
        }
    }

    // Method untuk mengecek apakah permainan selesai
    public boolean isGameOver() {
        if (bombHit) {
            return true; // Kalah karena bom
        }
        if (safeCount == TOTAL_SAFE) {
            return true; // Menang karena semua kotak aman terbuka
        }
        return false;
    }

    // Method untuk mendapatkan status bom (untuk pesan akhir)
    public boolean isBombHit() {
        return bombHit;
    }
}

// Kelas utama untuk menjalankan permainan
public class LotreGosok {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        LotreBoard board = new LotreBoard();

        System.out.println("Selamat datang di Lotre Gosok Bang Pawwry!");
        System.out.println("Buka semua 18 kotak aman tanpa menyentuh 2 bom.");
        System.out.println("Masukkan baris (0-3) dan kolom (0-4) untuk menggosok.");

        // Loop permainan
        while (!board.isGameOver()) {
            board.displayBoard();
            System.out.print("Masukkan baris: ");
            int row;
            try {
                row = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Error: Masukkan angka valid!");
                continue;
            }

            System.out.print("Masukkan kolom: ");
            int col;
            try {
                col = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Error: Masukkan angka valid!");
                continue;
            }

            // Proses tebakan
            boolean isSafe = board.guess(row, col);
            if (!isSafe) {
                break; // Bom ditemukan, keluar dari loop
            }
        }

        // Tampilkan papan akhir dan pesan hasil
        board.displayBoard();
        if (board.isBombHit()) {
            System.out.println("BOOM! Anda mengenai bom. Permainan selesai!");
        } else {
            System.out.println("Selamat! Anda membuka semua kotak aman!");
        }
        System.out.println("Terima kasih telah bermain Lotre Gosok Bang Pawwry!");

        scanner.close();
    }
}