package soal2;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

// Enum untuk jenis kendaraan
enum JenisKendaraan {
    MOTOR, MOBIL, TRUK
}

// Kelas soal2.Kendaraan untuk mengelola data kendaraan dan perhitungan biaya
class Kendaraan {
    private JenisKendaraan jenis;
    private double lamaParkir; // Dalam jam
    private double biaya;

    // Constructor
    public Kendaraan(JenisKendaraan jenis) {
        this.jenis = jenis;
        this.lamaParkir = 0;
        this.biaya = 0;
    }

    // Method untuk menghitung biaya berdasarkan durasi manual
    public void hitungBiaya(double lamaParkir) {
        this.lamaParkir = lamaParkir;
        double tarifPerJam = getTarifPerJam();
        this.biaya = lamaParkir * tarifPerJam;
        terapkanDiskon();
    }

    // Overloading: Menghitung biaya berdasarkan jam masuk dan jam keluar
    public void hitungBiaya(int jamMasuk, int jamKeluar) {
        if (jamKeluar < jamMasuk) {
            throw new IllegalArgumentException("Jam keluar harus lebih besar dari jam masuk!");
        }
        this.lamaParkir = jamKeluar - jamMasuk;
        double tarifPerJam = getTarifPerJam();
        this.biaya = lamaParkir * tarifPerJam;
        terapkanDiskon();
    }

    // Method untuk mendapatkan tarif per jam berdasarkan jenis kendaraan
    private double getTarifPerJam() {
        switch (jenis) {
            case MOTOR:
                return 2000; // Rp 2.000/jam
            case MOBIL:
                return 5000; // Rp 5.000/jam
            case TRUK:
                return 10000; // Rp 10.000/jam
            default:
                return 0;
        }
    }

    // Method untuk menerapkan diskon 10% jika parkir > 5 jam
    private void terapkanDiskon() {
        if (lamaParkir > 5) {
            biaya *= 0.9; // Diskon 10%
        }
    }

    // Method untuk menampilkan ringkasan
    public void tampilkanRingkasan() {
        System.out.println("Ringkasan Parkir:");
        System.out.println("Jenis soal2.Kendaraan: " + jenis);
        System.out.println("Lama Parkir: " + lamaParkir + " jam");
        System.out.printf("Total Biaya: Rp %.2f\n", biaya);
        System.out.println("-------------------");
    }

    // Getter untuk biaya dan jenis
    public double getBiaya() {
        return biaya;
    }

    public JenisKendaraan getJenis() {
        return jenis;
    }
}

// Kelas utama untuk menjalankan sistem parkir
public class ParkirChan {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<Kendaraan> daftarKendaraan = new ArrayList<>();
        boolean lanjut = true;

        System.out.println("Selamat datang di Sistem Parkir soal2.ParkirChan!");

        while (lanjut) {
            // Menu input jenis kendaraan
            System.out.println("\nPilih jenis kendaraan:");
            System.out.println("1. Motor");
            System.out.println("2. Mobil");
            System.out.println("3. Truk");
            System.out.print("Masukkan pilihan (1-3): ");
            int pilihanJenis = 0;
            try {
                pilihanJenis = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Error: Masukkan angka 1-3!");
                continue;
            }

            JenisKendaraan jenis;
            switch (pilihanJenis) {
                case 1:
                    jenis = JenisKendaraan.MOTOR;
                    break;
                case 2:
                    jenis = JenisKendaraan.MOBIL;
                    break;
                case 3:
                    jenis = JenisKendaraan.TRUK;
                    break;
                default:
                    System.out.println("Error: Pilihan tidak valid!");
                    continue;
            }

            // Membuat objek soal2.Kendaraan
            Kendaraan kendaraan = new Kendaraan(jenis);

            // Menu input durasi parkir
            System.out.println("\nPilih cara input durasi parkir:");
            System.out.println("1. Input jumlah jam secara langsung");
            System.out.println("2. Input jam masuk dan jam keluar");
            System.out.print("Masukkan pilihan (1-2): ");
            int pilihanDurasi = 0;
            try {
                pilihanDurasi = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Error: Masukkan angka 1-2!");
                continue;
            }

            try {
                if (pilihanDurasi == 1) {
                    // Input durasi manual
                    System.out.print("Masukkan lama parkir (jam): ");
                    double lamaParkir = Double.parseDouble(scanner.nextLine());
                    if (lamaParkir <= 0) {
                        System.out.println("Error: Lama parkir harus lebih dari 0!");
                        continue;
                    }
                    kendaraan.hitungBiaya(lamaParkir);
                } else if (pilihanDurasi == 2) {
                    // Input jam masuk dan keluar
                    System.out.print("Masukkan jam masuk (0-23): ");
                    int jamMasuk = Integer.parseInt(scanner.nextLine());
                    System.out.print("Masukkan jam keluar (0-23): ");
                    int jamKeluar = Integer.parseInt(scanner.nextLine());
                    if (jamMasuk < 0 || jamMasuk > 23 || jamKeluar < 0 || jamKeluar > 23) {
                        System.out.println("Error: Jam harus antara 0-23!");
                        continue;
                    }
                    kendaraan.hitungBiaya(jamMasuk, jamKeluar);
                } else {
                    System.out.println("Error: Pilihan tidak valid!");
                    continue;
                }
            } catch (NumberFormatException e) {
                System.out.println("Error: Masukkan angka yang valid!");
                continue;
            } catch (IllegalArgumentException e) {
                System.out.println("Error: " + e.getMessage());
                continue;
            }

            // Menambahkan kendaraan ke daftar dan menampilkan ringkasan
            daftarKendaraan.add(kendaraan);
            kendaraan.tampilkanRingkasan();

            // Tanya apakah ingin lanjut
            System.out.print("Tambah kendaraan lain? (y/n): ");
            String jawaban = scanner.nextLine().trim().toLowerCase();
            lanjut = jawaban.equals("y");
        }

        // Menampilkan ringkasan akhir
        System.out.println("\nRingkasan Akhir soal2.ParkirChan:");
        System.out.println("-------------------");
        System.out.println("Total soal2.Kendaraan: " + daftarKendaraan.size());
        double totalBiaya = 0;
        for (Kendaraan k : daftarKendaraan) {
            totalBiaya += k.getBiaya();
        }
        System.out.printf("Total Biaya Semua soal2.Kendaraan: Rp %.2f\n", totalBiaya);
        System.out.println("Terima kasih telah menggunakan Sistem Parkir soal2.ParkirChan!");

        scanner.close();
    }
}